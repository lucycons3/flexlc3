				<?php get_header(); ?>
					<div class="col-2 side">
						<?php get_sidebar(); ?>
					</div>
					<div class="col-8" style="padding-left:15%">	
						<h1>No lo encontramos, seguramente lo estemos preparando, busca algo:</h1>
						<p><?php get_search_form();?></p>
					</div>
				<?php get_footer(); ?>