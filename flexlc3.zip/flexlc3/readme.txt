#FlexLC3

**Contributors:** LC3
**Requires at least:** WordPress 4.0
**Tested up to:** WordPress 4.5
**Stable tag:** 0.1
**Version:** 0.1
**License:** GNU General Public License v4
**License URI:** https://creativecommons.org/licenses/by-nc-sa/4.0/
**Tags:** two-columns, left-sidebar, custom-colors, custom-header, custom-logo, custom-menu, featured-images, theme-options, blog, news

## Description

It is a Wordpress theme developed by [LC3](https://www.lucycons3.eu). It is a responsive and SEO friendly responsive blog. The design is creative and modern, it is responsive so it works on tablets, desktop computers and mobile phones on any system.

## Why is it special?

1. It is developed for a multiprupose web. It doesn't matter you have an small bussiness or a blog for talking about your hobbie, FlexLC3 fits you.
2. It supports Gutenberg plugin
3. We are improving it all the time.

## Copyright
FlexLC3 WordPress Theme, Copyright 2018 LC3
FlexLC3 is distributed under the terms of BY-NC-SA-04

This program is free software: you can redistribute it and/or modify
26	it under the terms of the GNU General Public License as published by
27	the Free Software Foundation, either version 4 of the License, or
28	(at your option) any later version.

This program is distributed in the hope that it will be useful,
31	but WITHOUT ANY WARRANTY; without even the implied warranty of
32	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
33	GNU General Public License for more details.

IMG FROM SCREENSHOT

Included in the screenshot:
https://pixabay.com/en/noodles-pasta-macaroni-gobbetti-3559956/
https://pixabay.com/en/crow-bird-raven-blackbird-animal-3604685/

Font
- Roboto -
License: Apache License 2.0
License URI: https://www.apache.org/licenses/LICENSE-2.0

- Oswald -
License: SIL OPEN FONT LICENSE Version 1.1
License URI: https://scripts.sil.org/OFL

*The logo is made by us in Inkscape
