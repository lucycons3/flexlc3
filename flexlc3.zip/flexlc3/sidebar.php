
					<strong style="margin-top:12%;">Temas</strong>
					<?php wp_nav_menu( array ( 'menu' => 'sidebar') ); ?>
					
					<strong style="margin-top:12%;">Busca lo que quieras</strong>
					<?php get_search_form(); ?>
					
					<?php if ( is_active_sidebar( 'sidebar-lateral' ) ) : ?>
							<?php dynamic_sidebar( 'sidebar-lateral' ); ?>
					<?php endif; ?>

